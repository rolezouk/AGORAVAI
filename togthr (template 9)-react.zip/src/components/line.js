import React from 'react'

import './line.css'

const Line = (props) => {
  return <div className="line-line"></div>
}

export default Line
